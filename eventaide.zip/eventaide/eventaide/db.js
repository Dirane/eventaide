const mysql = require('mysql');
const express = require('express');
const cors = require('cors');

const app = express();
app.use(cors());

const connection = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '',
});

connection.connect((err) => {
    if (err) throw new Error(err);
    console.log('Connected to MySQL');

    // Create database if it doesn't exist
    connection.query('CREATE DATABASE IF NOT EXISTS eventaid', (err) => {
        if (err) throw new Error(err);
        console.log("Database created or already exists");

        // Change to the newly created database
        connection.changeUser ({ database: 'eventaid' }, (err) => {
            if (err) throw new Error(err);
            createTables(); // Call the function to create tables
        });
    });
});

// Function to create tables
function createTables() {
    // Create users table
    connection.query(`CREATE TABLE IF NOT EXISTS users ( 
        UserID INT AUTO_INCREMENT NOT NULL PRIMARY KEY,
        Name VARCHAR(30),
        Email VARCHAR(30),
        Role VARCHAR(3),
        Password VARCHAR(30),
        Phone_Number VARCHAR(30)
        
    )`, (err) => {
        if (err) throw new Error(err);
        console.log('Users table created or already exists');
    });

    // Create events table
    connection.query(`CREATE TABLE IF NOT EXISTS events ( 
        event_id INT AUTO_INCREMENT NOT NULL PRIMARY KEY,
        title VARCHAR(30),
        Description TEXT(255),
        Start_Time Timestamp(20),
        location VARCHAR(30),
        Oraganizer_id VARCHAR(30),
        Category VARCHAR(30),
        Status VARCHAR(30),
        Created_at Timestamp(20)
        
    )`, (err) => {
        if (err) throw new Error(err);
        console.log('Events table created or already exists');
    });

//..........................
    connection.query(`CREATE TABLE IF NOT EXISTS registration ( 
        Registration_id INT AUTO_INCREMENT NOT NULL PRIMARY KEY,
        event_id VARCHAR(30),
        user_id  VARCHAR(30),
        registration_date Timestamp(10),
        Ticket_type VARCHAR(30),
        payment_status VARCHAR(30),
        created_at Timestamp(10)
        
    )`, (err) => {
        if (err) throw new Error(err);
        console.log('registration table created or already exists');
    });
}

// Start the server
app.listen(3000, () => {
    console.log('Server is running on port 3000');
});